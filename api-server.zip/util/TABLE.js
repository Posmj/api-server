const TABLE = {
  TODO: "todo",
  USER: "user",
};

module.exports = TABLE;